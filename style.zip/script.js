// GLOBAL VARIABLES FOR SORTING
var lstMember = new Array();
var parent = new Array();
var equal = new Array();
var rec = new Array();
var cmp1, cmp2;
var head1, head2;
var nrec;
var numQuestion;
var totalSize;
var finishSize;
var finishKit;

function initList() {
    console.log("initList ran");
    var n = 0;
    var mid;
    var i;
    shuffleArray(namMember);
    lstMember[n] = new Array();
    for (i = 0; i < namMember.length; i++) {
        lstMember[n][i] = i;
    }
    parent[n] = -1;
    totalSize = 0;
    n++;
    for (i = 0; i < lstMember.length; i++) {
        if (lstMember[i].length >= 2) {
            mid = Math.ceil(lstMember[i].length / 2);
            lstMember[n] = lstMember[i].slice(0, mid);
            totalSize += lstMember[n].length;
            parent[n] = i;
            n++;
            lstMember[n] = lstMember[i].slice(mid, lstMember[i].length);
            totalSize += lstMember[n].length;
            parent[n] = i;
            n++;
        }
    }
    for (i = 0; i < namMember.length; i++) {
        rec[i] = 0;
    }
    nrec = 0;
    for (i = 0; i <= namMember.length; i++) {
        equal[i] = -1;
    }
    cmp1 = lstMember.length - 2;
    cmp2 = lstMember.length - 1;
    head1 = 0;
    head2 = 0;
    numQuestion = 1;
    finishSize = 0;
    finishKit = 0;
}

function sortList(kit) {
    console.log("sortList ran");
    var i;
    var str;
    if (kit < 0) {
        rec[nrec] = lstMember[cmp1][head1];
        head1++;
        nrec++;
        finishSize++;
        while (equal[rec[nrec - 1]] != -1) {
            rec[nrec] = lstMember[cmp1][head1];
            head1++;
            nrec++;
            finishSize++;
        }
    } else if (kit > 0) {
        rec[nrec] = lstMember[cmp2][head2];
        head2++;
        nrec++;
        finishSize++;
        while (equal[rec[nrec - 1]] != -1) {
            rec[nrec] = lstMember[cmp2][head2];
            head2++;
            nrec++;
            finishSize++;
        }
    } else {
        rec[nrec] = lstMember[cmp1][head1];
        head1++;
        nrec++;
        finishSize++;
        while (equal[rec[nrec - 1]] != -1) {
            rec[nrec] = lstMember[cmp1][head1];
            head1++;
            nrec++;
            finishSize++;
        }
        equal[rec[nrec - 1]] = lstMember[cmp2][head2];
        rec[nrec] = lstMember[cmp2][head2];
        head2++;
        nrec++;
        finishSize++;
        while (equal[rec[nrec - 1]] != -1) {
            rec[nrec] = lstMember[cmp2][head2];
            head2++;
            nrec++;
            finishSize++;
        }
    }
    if (head1 < lstMember[cmp1].length && head2 == lstMember[cmp2].length) {
        while (head1 < lstMember[cmp1].length) {
            rec[nrec] = lstMember[cmp1][head1];
            head1++;
            nrec++;
            finishSize++;
        }
    } else if (head1 == lstMember[cmp1].length && head2 < lstMember[cmp2].length) {
        while (head2 < lstMember[cmp2].length) {
            rec[nrec] = lstMember[cmp2][head2];
            head2++;
            nrec++;
            finishSize++;
        }
    }
    if (head1 == lstMember[cmp1].length && head2 == lstMember[cmp2].length) {
        for (i = 0; i < lstMember[cmp1].length + lstMember[cmp2].length; i++) {
            lstMember[parent[cmp1]][i] = rec[i];
        }
        lstMember.pop();
        lstMember.pop();
        cmp1 = cmp1 - 2;
        cmp2 = cmp2 - 2;
        head1 = 0;
        head2 = 0;
        if (head1 == 0 && head2 == 0) {
            for (i = 0; i < namMember.length; i++) {
                rec[i] = 0;
            }
            nrec = 0;
        }
    }
    if (cmp1 < 0) {
        str = "Matchup #" + (numQuestion - 1) + "<br>" + Math.floor(finishSize * 100 / totalSize) + "% sorted.";
        document.getElementById("matchupNumber").innerHTML = str;
        document.getElementById("progressBar").style.display = "none";
        showResult();
        finishKit = 1;
    } else {
        showImage();
    }
}

function showResult() {
    console.log("showResult ran");
    // Process kit info: update image paths to use 150x folder and remove any "2025 " prefix
    var processedNamMember = namMember.map(item => item.replace(/\/png\//g, "/png/150x/").replace("2025 ", ""));
    var ranking = 1;
    var sameRank = 1;
    var str = "";
    var strx = "!submit 2025 ";
    var i;
    str += "<table style=\"width:100%; font-size:16px; border:0px solid #FFFFFF; background-color:#FFFFFF;\" align=\"center\">";
    str += "<tr>";
    str += "<td style=\"text-align:left; font-weight:bold; font-size:24px; padding-left:20px; padding-top:5px;\">MLS Kit Rankings</td>";
    str += "<td style=\"text-align:right; font-size:10px; padding-right:20px;\">Created by: Joseph Même | @ThreeDEF</td>";
    str += "</tr>";
    str += "<tr><td colspan=\"2\"><hr></td></tr>";
    // For a 4x8 layout, use modulo 8
    str += "<table style=\"width:200px; font-size:16px; border:0px solid #FFFFFF; background-color:#FFFFFF;\" align=\"center\">";
    for (i = 0; i < processedNamMember.length; i++) {
        if (i % 8 === 0) {
            if (i !== 0) {
                str += "</tr>";
            }
            str += "<tr style=\"height: auto;\">";
        }
        var memberInfo = processedNamMember[lstMember[0][i]].split("|");
        str += "<td style=\"border:1px solid #00025d; padding-left:1px; padding-right:1px; background-color:" + 
               /* use colors array defined inline */ 
               ["#00ff57", "#3ef846", "#56f034", "#67e91d", "#75e200", "#80da00", "#89d300", "#91cb00", "#99c300", "#9fbc00",
                "#a4b400", "#a9ac00", "#aea400", "#b19c00", "#b49400", "#b78c00", "#b98400", "#bb7b00", "#bc7300", "#bd6a00",
                "#bd6200", "#bd5900", "#bc5000", "#bb4700", "#ba3d00", "#b83300", "#b52700", "#b21a00", "#af0404", "#ac0000",
                "#a80000", "#a40000"][ranking-1] + 
               "; font-size: 12px; text-align:center; font-weight:bolder;\">" 
             + "#" + ranking + ": " 
             + "<span style=\"font-size:11px;\">" + memberInfo[1] + "<br>" + memberInfo[0] + "</span><br>"
             + "<span style=\"font-size:8px; line-height:10px\">" + memberInfo[2] + "</span></td>";
        strx += memberInfo[0] + ", ";
        if (i < processedNamMember.length - 1) {
            if (equal[lstMember[0][i]] == lstMember[0][i+1]) {
                sameRank++;
            } else {
                ranking += sameRank;
                sameRank = 1;
            }
        }
    }
    str += "</tr>";
    str += "<tr style=\"height: 20px;\"></tr>";
    str += "</table></div>";
    strx = strx.replace(/, \B/, "");
    // Insert the final results into the hidden container
    document.getElementById("resultsContainer").innerHTML = str;
    // Show the "Show Results" button
    document.getElementById("screenieButton").innerHTML = "<br><button onclick=\"generateShareableImage()\" style=\"font-size: 20px; padding: 10px 20px; background-color: #ccc; border: none; border-radius: 5px\">Show Results</button>";
    document.getElementById("screenieButton").style.display = "block";
}

function showImage() {
    console.log("showImage ran");
    var completionPercentage = Math.floor(finishSize * 100 / totalSize);
    var progressBar = '<div style="width: auto; height: 30px; background-color: #f0f0f0; border: 1px solid #ccc; border-radius: 5px; margin: 10px auto;">';
    progressBar += '<div style="width: ' + completionPercentage + '%; height: 100%; background-color: #4caf50; border-radius: 5px;"></div>';
    progressBar += '</div>';
    
    var str0 = "Matchup #" + numQuestion + "<br>" + completionPercentage + "% sorted.";
    var str1 = "<div style='width: 300px; height: 300px; background-color: white; margin: 0 auto;'>" + namMember[lstMember[cmp1][head1]].split("|")[0] + "</div>";
    var str2 = "<div style='width: 300px; text-align: center; font-size:18px;'>" + namMember[lstMember[cmp1][head1]].split("|")[1] + "</div>";
    var str3 = "<div style='width: 300px; text-align: center; font-size:12px;'>" + namMember[lstMember[cmp1][head1]].split("|")[2] + "</div>";
    var str4 = "<div style='width: 300px; height: 300px; background-color: white; margin: 0 auto;'>" + namMember[lstMember[cmp2][head2]].split("|")[0] + "</div>";
    var str5 = "<div style='width: 300px; text-align: center; font-size:18px;'>" + namMember[lstMember[cmp2][head2]].split("|")[1] + "</div>";
    var str6 = "<div style='width: 300px; text-align: center; font-size:12px;'>" + namMember[lstMember[cmp2][head2]].split("|")[2] + "</div>";
    
    document.getElementById("matchupNumber").innerHTML = str0;
    document.getElementById("leftField").innerHTML = str1 + str2 + str3;
    document.getElementById("rightField").innerHTML = str4 + str5 + str6;
    numQuestion++;
    document.getElementById("progressBar").innerHTML = progressBar;
}

function toNameFace(n) {
    console.log("toNameFace ran");
    var str = namMember[n];
    return str;
}

// New function to generate a shareable image from the results container
function generateShareableImage() {
    // Reveal the results container if hidden
    var container = document.getElementById("resultsContainer");
    container.style.display = "block";
    
    domtoimage.toPng(container)
    .then(function(dataUrl) {
        // Create a modal to display the shareable image
        var modal = document.createElement('div');
        modal.style.position = 'fixed';
        modal.style.zIndex = '9999';
        modal.style.top = '0';
        modal.style.left = '0';
        modal.style.width = '100vw';
        modal.style.height = '100vh';
        modal.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
        modal.style.display = 'flex';
        modal.style.justifyContent = 'center';
        modal.style.alignItems = 'center';
        
        var img = new Image();
        img.src = dataUrl;
        img.style.maxWidth = '90%';
        img.style.maxHeight = '90%';
        
        modal.appendChild(img);
        modal.addEventListener('click', function() {
            document.body.removeChild(modal);
        });
        document.body.appendChild(modal);
    })
    .catch(function(error) {
        console.error("Error generating shareable image", error);
    });
}

// Initialize list and show first matchup
initList();
showImage();
